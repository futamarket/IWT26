// ════════════════════════════════════════════════════════════════
//  DLCF FUTA IWT 2025 — Google Apps Script Backend
//  Paste this entire file into Google Apps Script, then Deploy
// ════════════════════════════════════════════════════════════════

const SHEET_NAME = "IWT_Results";

function doPost(e) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(SHEET_NAME);

    // Create sheet with headers if it doesn't exist
    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
      const headers = [
        "Submission ID", "Timestamp", "Full Name", "Matric Number", "Level", "Gender",
        "WTC101 (/40)", "WTC102 (/40)", "WTC103 (/40)", "WTC104 (/40)", "WTC105 (/40)",
        "Total Score (/200)", "Percentage (%)", "Time Taken"
      ];
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);

      // Style header row
      const headerRange = sheet.getRange(1, 1, 1, headers.length);
      headerRange.setBackground("#1a237e");
      headerRange.setFontColor("#ffffff");
      headerRange.setFontWeight("bold");
      sheet.setFrozenRows(1);
    }

    // Parse incoming data
    const data = JSON.parse(e.postData.contents);

    const row = [
      data.id,
      new Date(data.timestamp).toLocaleString("en-NG"),
      data.student.name,
      data.student.matric,
      data.student.level,
      data.student.gender,
      data.scores.wtc101,
      data.scores.wtc102,
      data.scores.wtc103,
      data.scores.wtc104,
      data.scores.wtc105,
      data.totalScore,
      data.percentage + "%",
      data.timeTaken
    ];

    sheet.appendRow(row);

    // Auto-resize columns
    sheet.autoResizeColumns(1, 14);

    return ContentService
      .createTextOutput(JSON.stringify({ success: true }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ success: false, error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  return ContentService
    .createTextOutput("DLCF IWT Exam Backend is running ✅")
    .setMimeType(ContentService.MimeType.TEXT);
}
