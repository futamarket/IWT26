# DLCF FUTA IWT 2025 — Exam Web App

## Files
- `index.html` — Main app (all screens)
- `css/style.css` — Styling
- `js/app.js` — Exam logic, timer, admin
- `data/questions.js` — All 200 questions (5 × 40)
- `backend.gs` — Google Apps Script for cloud storage

---

## Deploy to GitHub Pages
1. Create a new GitHub repo (e.g. `dlcf-iwt-2025`)
2. Upload all files keeping the folder structure
3. Go to Settings → Pages → Branch: main → Save
4. Your exam link: `https://yourusername.github.io/dlcf-iwt-2025/`

---

## Cloud Sync Setup (Google Sheets — REQUIRED for seeing all results)

### Step 1: Create a Google Sheet
1. Go to sheets.google.com → New spreadsheet
2. Name it: "IWT 2025 Results"

### Step 2: Add the Script
1. Extensions → Apps Script
2. Delete all existing code
3. Paste the entire content of `backend.gs`
4. Click Save (name it anything e.g. "IWT Backend")

### Step 3: Deploy
1. Click Deploy → New deployment
2. Type: Web App
3. Execute as: **Me**
4. Who has access: **Anyone**
5. Click Deploy → Authorize → Copy the Web App URL

### Step 4: Link to your exam app
1. Open `js/app.js`
2. Find this line near the top:
   ```js
   let SUBMIT_URL = "";
   ```
3. Replace with:
   ```js
   let SUBMIT_URL = "https://script.google.com/macros/s/YOUR_COPIED_URL/exec";
   ```
4. Save and re-upload to GitHub

Now every student submission goes LIVE into your Google Sheet instantly!

---

## Admin Panel
- Access: scroll to bottom of landing page → "Admin Portal"
- Password: `DLCF@Admin2025`
- Features: view all results, scores per course, export CSV
- Change password in `js/app.js` → `ADMIN_PASSWORD`

---

## Timer
- 100 minutes for all 5 sections
- Turns orange at 10 minutes remaining
- Turns red and pulses at 5 minutes remaining
- Auto-submits when time expires
